-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 28, 2015 at 06:10 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stakeholder`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE IF NOT EXISTS `activity` (
`ac_id` int(4) NOT NULL,
  `ac_no` int(4) NOT NULL,
  `ac_name` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `position` varchar(100) NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`ac_id`, `ac_no`, `ac_name`, `type`, `status`, `position`, `description`, `created`) VALUES
(1, 1, 'การระบุความเสี่ยงและการประเมินความเสี่ยง', 'risk', 'activated', '["3","4","5","6"]', 'testing', '2015-02-08 15:38:18'),
(2, 2, 'การระบุผู้มีส่วนได้ส่วนเสีย', 'stakeholder', 'activated', '["1","2"]', 'ทดสอบ', '2015-02-08 15:38:18'),
(3, 3, 'SWOT and TOWS Analysis', 'swot-tows', '', '', NULL, '2015-02-28 10:59:03');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE IF NOT EXISTS `answer` (
`ans_id` int(4) NOT NULL,
  `ans_detail` text NOT NULL,
  `user_id` int(4) NOT NULL,
  `ac_id` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`ans_id`, `ans_detail`, `user_id`, `ac_id`) VALUES
(1, '[["การทำงานหนัก","5","4","20"],["ความสามัคคี","3","4","12"],["ความคิดสร้างสรรค์","2","4","8"]]', 2, 1),
(2, '[["พนักงาน","มีสวัสดิการที่ดีขึ้น"],["เพื่อนร่วมงาน","มีความสามัคคีมากขึ้น"]]', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `stakeholder`
--

CREATE TABLE IF NOT EXISTS `stakeholder` (
`stk_id` int(4) NOT NULL,
  `ac_id` int(4) NOT NULL,
  `stklist_id` int(4) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stakeholder`
--

INSERT INTO `stakeholder` (`stk_id`, `ac_id`, `stklist_id`) VALUES
(1, 1, 3),
(2, 1, 4),
(3, 1, 5),
(4, 1, 6),
(5, 2, 1),
(6, 2, 2),
(7, 3, 7),
(8, 3, 8),
(9, 3, 9),
(10, 3, 10);

-- --------------------------------------------------------

--
-- Table structure for table `stakeholder_list`
--

CREATE TABLE IF NOT EXISTS `stakeholder_list` (
`stklist_id` int(4) NOT NULL,
  `stklist_name` varchar(200) NOT NULL,
  `stklist_type` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stakeholder_list`
--

INSERT INTO `stakeholder_list` (`stklist_id`, `stklist_name`, `stklist_type`) VALUES
(1, 'Stakeholder', 'text'),
(2, 'Interest', 'text'),
(3, 'ประเภทความเสี่ยง', 'text'),
(4, 'โอกาส', 'level'),
(5, 'ผลกระทบ', 'level'),
(6, 'ระดับความเสี่ยง', 'sum'),
(7, 'Internal Strengths (S)', 'text'),
(8, 'Internal Weaknesses (W)', 'text'),
(9, 'External Opportunities (O)', 'text'),
(10, 'External Threats (T)', 'text');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(4) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `group` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `group`, `name`, `created`) VALUES
(1, 'test', '1234', 'admin', 'name_test', '2015-02-05 02:32:20'),
(2, 'usert', '1234', 'user', 'name', '2015-02-23 19:38:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
 ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
 ADD PRIMARY KEY (`ans_id`);

--
-- Indexes for table `stakeholder`
--
ALTER TABLE `stakeholder`
 ADD PRIMARY KEY (`stk_id`);

--
-- Indexes for table `stakeholder_list`
--
ALTER TABLE `stakeholder_list`
 ADD PRIMARY KEY (`stklist_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
MODIFY `ac_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
MODIFY `ans_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `stakeholder`
--
ALTER TABLE `stakeholder`
MODIFY `stk_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `stakeholder_list`
--
ALTER TABLE `stakeholder_list`
MODIFY `stklist_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
